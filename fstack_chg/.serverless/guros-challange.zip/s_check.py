import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='lupnox',
    application_name='guros-challange',
    app_uid='xYmlfgvqRvYVVVPnNp',
    org_uid='x8rPJxn4t5gRNKpDfV',
    deployment_uid='f85fe6e6-6083-491e-a462-d4da65af2c3c',
    service_name='guros-challange',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'guros-challange-dev-check', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('dna_check.cerebro')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
